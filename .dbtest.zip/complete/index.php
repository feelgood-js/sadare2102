<form method="POST" action="method.php"> 
    <input type="text" name="id" placeholder="ID" /> 
    <input type="password" name="password" placeholder="Password" /> 
    <input type="text" name="name" placeholder="Your Name" /> &nbsp; 
    <button type="submit">제출</button> 
    <a href="select.php"><button type="button">필드 조회하러 가기</button></a> &nbsp;


</form>